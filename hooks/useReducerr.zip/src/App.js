import "./styles.css";
import {useReducer} from 'react'

const startingState = {count: 0}

const reducer = (state, action) => {
      switch(action.type){
        case 'increment':
        return {count : state.count + 1}

        default:
        return 'Error'
      }
}

export default function App() {
  const [state, dispatch] = useReducer(reducer, startingState);
  return (
    <div className="App">
      <h1>{state.count}</h1>
     
      <button onClick = {() => dispatch({type : 'increment'})}>Increment</button>
    </div>
  );
}
