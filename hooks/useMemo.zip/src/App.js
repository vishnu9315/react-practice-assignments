import "./styles.css";
import {useState, useMemo} from 'react'
export default function App() {
  const [counter1, setCounter1] = useState(0)
  const [counter2, setCounter2] = useState(0)
  
  const increment1 = () => {
    setCounter1(counter1 + 1)
  }
   const increment2 = () => {
    setCounter2(counter2 + 1)
  }

  const isEven = useMemo(() => {
    console.log("---------")
    let i = 0;
    while (i < 10001 ) i++;
    return counter1 % 2 === 0;
  }, [counter1])

  


  return (
    <div className="App">
      <h1>Hello CodeSandbox</h1>
     <button onClick = {increment1}>Increment- {counter1}</button>
     <span> {isEven ? "Even" : "Odd"} </span>
     <button onClick = {increment2}>Increment- {counter2}</button>
    </div>
  );
}
