
import ChildComponent from './ChildComponent'
const MainComponent = () => {
  return (  
    <>
     <ChildComponent />
    </>
  )
}
export default MainComponent;