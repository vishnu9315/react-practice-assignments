export default [
  "FAKE: electronics",
  "FAKE: jewelery",
  "FAKE: men's clothing",
  "FAKE: women's clothing",
];
