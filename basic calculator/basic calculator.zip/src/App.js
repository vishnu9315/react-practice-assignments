import "./styles.css";
import Input from "./Input";
export default function App() {
  return (
    <div className="App">
      <Input />
    </div>
  );
}
